package com.system.mapper;

import java.util.List;

import com.system.pojo.Details;

public class DetailsMapperImpl implements DetailsMapper{

	@Override
	public int addDetails(Details details) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delDetailsByNo(String transactionNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int editDetailsByNo(Details details) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Details> getDetailsByBarCode(String g_barCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Details> getDetailsByName(String g_name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Details> getDetailsByNo(String transactionNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Details> getDetailsList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDetailsCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Details> getPartAllDetails(int page, int size) {
		// TODO Auto-generated method stub
		return null;
	}

}
