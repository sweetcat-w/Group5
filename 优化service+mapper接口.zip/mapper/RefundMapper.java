package com.system.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.system.pojo.Refund;

public interface RefundMapper {
	/**
	 * 添加商品退货登记
	 * @param refund 添加的信息
	 * @return 影响行数
	 */
	public int addRefund(Refund refund); 
	
	/**
	 * 按交易单号删除退货登记
	 * @param transactionNo 交易单号
	 * @return 影响行数
	 */
	public int delRefundByNo(@Param("transactionNo") String transactionNo);
	
	/**
	 * 按交易单号修改退货登记
	 * @param transactionNo 交易单号
	 * @return  
	 */
	public int editRefundByNo(Refund refund);
	
	/**
	 * 按商品条形码查询退货登记
	 * @param g_barCode 商品条形码
	 * @return 查询结果
	 */
	public List<Refund> getRefundByBarCode(@Param("g_barCode") String g_barCode);

	/**
	 * 按商品名称查询退货登记
	 * @param g_name 商品名称
	 * @return 查询结果
	 */
	public List<Refund> getRefundByName(@Param("g_name") String g_name);
	
	/**
	 * 按交易单号查询退货登记
	 * @return 查询结果
	 */
	public List<Refund> getRefundByNo(@Param("transactionNo") String transactionNo);
		
	/**
	 * 获取全部退货登记
	 * @return 退货登记列表
	 */
	public List<Refund> getRefundList();
	
	/**
	 * 获取全部退货登记总数
	 * @return 统计结果
	 */
	public int getRefundCount();
	
	/**
	 * 分页处理退货登记
	 * @param page 页
	 * @param size 分页大小
	 * @return
	 */
	public List<Refund> getPartAllRefund(int page, int size);

}

