package com.system.mapper;

import java.util.List;

import com.system.pojo.Refund;

public class RefundMapperImpl implements RefundMapper{

	@Override
	public int addRefund(Refund refund) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delRefundByNo(String transactionNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int editRefundByNo(Refund refund) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Refund> getRefundByBarCode(String g_barCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Refund> getRefundByName(String g_name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Refund> getRefundByNo(String transactionNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Refund> getRefundList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getRefundCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Refund> getPartAllRefund(int page, int size) {
		// TODO Auto-generated method stub
		return null;
	}
}
