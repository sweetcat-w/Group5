package com.system.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.system.pojo.User;

//新增用户信息 AddUserServlert

@WebServlet("/servlet/AddUserServlert")

public class AddUserServlert extends HttpServlet{
	
private static final long serialVersionUID = 1L;
	
    public AddUserServlert() {
        super();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
    	resp.setContentType("text/html;charset=utf-8");
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
		//返回调用方法返回获得的用户集合
		req.setAttribute("UserList", userServiceImpl.getUserList());
		//返回到添加用户信息页面
		req.getRequestDispatcher("/manager/UserAdd.jsp").forward(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		//获取发送到HttpSession的数据来为新页面提供内容
		HttpSession session = req.getSession();	
		
		//获取用户id
		String id = req.getParameter("id");	//id
		
		//判断id是否存在，若是不存在则添加
		if(userServiceImpl.getUserByNo(id).size() == 0) {
			
			//获取页面上需要添加的信息
			String name = req.getParameter("name");	//用户名称
			String password = req.getParameter("password");	//密码
			String phoneNum = req.getParameter("phoneNum");	//用户电话
			 boolean isAdmain = req.getParameter("isAdmain") != null;	//是否为管理员
			
			//创建一个进货明细对象
			User user = new User();
			//将相应的信息添加到对象中
			user.setId(id);
			user.setUserName(name);
			user.setPassword(password);
			user.setPhoneNum(phoneNum);
			user.setAdmain(isAdmain);

			//实例化接口
			UserService serviceImpl = new UserServiceImpl();
			//调用接口的添加进货明细方法，返回结果到页面并提示
			
			if(serviceImpl.addUser(user) > 0){
				out.write("<script>");
				out.write("alert('【用户信息管理】添加成功！');");
				out.write("location='GetUserListServlert';");
				out.write("</script>");
			}else {
				out.write("<script>");
				out.write("alert('【用户信息管理】添加失败！');");
				out.write("location='AddUserServlert';");
				out.write("</script>");
			}
		}else {
			out.write("<script>");
			out.write("alert('【用户信息管理】已存在，请重新输入！');");
			out.write("location='AddUserServlert';");
			out.write("</script>");
		}
    }   
    
}
