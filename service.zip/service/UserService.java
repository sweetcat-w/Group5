package com.system.service;

public interface UserService {

}
