package com.system.service;

import com.system.pojo.Refund;
import java.util.ArrayList;
import java.util.List;
import com.system.mapper.RefundMapper;
import com.system.mapper.RefundMapperImpl;

public class RefundServiceImpl implements RefundService{
	
	private RefundMapper refundMapper = new RefundMapperImpl();

	@Override
	public int addRefund(Refund refund) {
		
		return refundMapper.addRefund(refund);
	}

	@Override
	public int delRefundByNo(String transactionNo) {
		
		return refundMapper.delRefundByNo(transactionNo);
	}

	@Override
	public int editRefundByNo(Refund refund) {
		
		return refundMapper.editRefundByNo(refund);
	}

	@Override
	public List<Refund> getRefundByBarCode(String g_barCode) {
		
		return refundMapper.getRefundByBarCode(g_barCode);
	}

	@Override
	public List<Refund> getRefundByName(String g_name) {
		
		return refundMapper.getRefundByName(g_name);
	}

	@Override
	public List<Refund> getRefundByNo(String transactionNo) {
		
		return refundMapper.getRefundByNo(transactionNo);
	}

	@Override
	public List<Refund> getPartAllRefund() {
		
		return refundMapper.getRefundList();
	}

	@Override
	public int getrefundCount() {
		
		return refundMapper.getRefundCount();
	}

	@Override
	public List<Refund> getPartAllRefund(int page, int size) {
		
		int pageSize = 0;
		List<Refund> rList = RefundMapper.getRefundList();
		
		//创建refundLists存放分页处理后的数据
		List<Refund> RefundList = new ArrayList<Refund>();
		//分页处理
        if((page-1) * size + size > rList.size()){	
            pageSize = rList.size();
        }else {
            pageSize = (page-1) * size + size;
        }
        for (int i = (page-1) * size; i < pageSize; i++) {
        	Refund refund = rList.get(i);
        	RefundList.add(refund);
        }
		return RefundList;
	}
	}


}
