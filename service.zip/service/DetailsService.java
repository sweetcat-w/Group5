package com.system.service;

public interface DetailsService {

}
