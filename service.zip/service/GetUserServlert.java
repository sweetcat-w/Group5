package com.system.service;
//查询全部用户信息
public class GetUserServlert {

}
