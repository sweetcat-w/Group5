package com.system.service;

public class DetailsServiceImpl implements DetailsService {

}
