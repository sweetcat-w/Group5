package com.system.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.system.pojo.Details;
import com.system.pojo.Registration;

public interface RegistrationMapper {
	
	/**
	 * 添加商品进货登记
	 * @param Registration 添加的信息
	 * @return 影响行数
	 */
	public int addRegistration(Registration registration);
	
	/**
	 * 按交易单号删除进货登记
	 * @param transactionNo 交易单号
	 * @return 影响行数
	 */
	public int delRegistrationServiceByNo(@Param("transactionNo") String transactionNo);
	
	/**
	 * 按交易单号修改进货登记
	 * @param transactionNo 交易单号
	 * @return  
	 */
	public int editRegistrationByNo(Registration registration);
	
	/**
	 * 按交易日期查询进货登记
	 * @param transactionDate 交易日期
	 * @return 查询结果
	 */
	public List<Registration> getRegistrationByDate(@Param("transactionDate") String transactionDate);

	/**
	 * 按供应商查询进货登记
	 * @param supplier 供应商
	 * @return 查询结果
	 */
	public List<Registration> getRegistrationBySupplier(@Param("supplier") String supplier);
	
	/**
	 * 按交易单号查询进货登记
	 * @return 查询结果
	 */
	public List<Registration> getRegistrationByNo(@Param("transactionNo") String transactionNo);
	
	/**
	 * 获取全部进货登记
	 * @return 进货登记列表
	 */
	public List<Registration> getRegistrationList();
	
	/**
	 * 获取全部进货登记总数
	 * @return 统计结果
	 */
	public int getRegistrationCount();
}
