package com.system.controller.details;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.system.pojo.Details;
import com.system.service.DetailsService;
import com.system.service.DetailsServiceImpl;

//新增商品进货明细 AddDetailsServlert

@WebServlet("/servlet/AddDetailsServlert")
public class AddDetailsServlert extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
    public AddDetailsServlert() {
        super();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
    	resp.setContentType("text/html;charset=utf-8");
		//实例化接口
		DetailsService detailsServiceImpl = new DetailsServiceImpl();
		//返回调用方法返回获得的进货明细集合
		req.setAttribute("detailsList", detailsServiceImpl.getDetailsList());
		//返回到添加进货明细页面
		req.getRequestDispatcher("/manager/detailsAdd.jsp").forward(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		//获取发送到HttpSession的数据来为新页面提供内容
		HttpSession session = req.getSession();	
		
		//获取进货明细的交易单号
		String transactionNo = req.getParameter("transactionNo"); 
		
		//实例化接口
		DetailsService detailsServiceImpl = new DetailsServiceImpl();
		//判断交易单号不存在则进行添加操作
		if(detailsServiceImpl.getDetailsByNo(transactionNo).size() == 0) {
			
			//设置日期格式
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
			
			//获取页面上需要添加的信息
			String suppler = req.getParameter("suppler");	//供货商
			String transactionDate = req.getParameter("transactionDate");	//交易日期
			String g_name = req.getParameter("g_name");	//商品名称
			String g_barCode = req.getParameter("g_barCode");	//商品条形码
			String g_manufactureDate = req.getParameter("g_manufactureDate");	//生产日期
			int g_num = Integer.parseInt(req.getParameter("g_num"));	//数量
			String g_specification = req.getParameter("g_specification");	//规格
			String g_unit = req.getParameter("g_unit");	//单位
			String g_type = req.getParameter("g_type");	//商品类型
			int g_shelfLife = Integer.parseInt("g_shelfLife");	////保质期
			
			//创建一个进货明细对象
			Details details = new Details();
			//将相应的信息添加到对象中
			details.setTransactionNo(transactionNo);
			details.setSuppler(suppler);
			details.setTransactionDate(new Date(simpleDateFormat.parse(transactionDate).getTime()));
			details.setG_name(g_name);
			details.setG_barCode(g_barCode);
			details.setG_manufactureDate(new Date(simpleDateFormat.parse(g_manufactureDate).getTime()))
			details.setG_num(g_num);
			details.setG_specification(g_specification);
			details.setG_unit(g_unit);
			details.setG_type(g_type);
			details.setG_shelfLife(g_shelfLife);

			//实例化接口
			DetailsService serviceImpl = new DetailsServiceImpl();
			//调用接口的添加进货明细方法，返回结果到页面并提示
			
			if(serviceImpl.addDetails(details) > 0){
				out.write("<script>");
				out.write("alert('【进货明细】添加成功！');");
				out.write("location='GetDetailsListServlert';");
				out.write("</script>");
			}else {
				out.write("<script>");
				out.write("alert('【进货明细】添加失败！');");
				out.write("location='AddDetailsServlert';");
				out.write("</script>");
			}
		}else {
			out.write("<script>");
			out.write("alert('【进货明细】交易单号已存在，请重新输入！');");
			out.write("location='AddDetailsServlert';");
			out.write("</script>");
		}
    }   
}
