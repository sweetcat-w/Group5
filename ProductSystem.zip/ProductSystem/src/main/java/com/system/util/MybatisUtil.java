package com.system.util;

import java.io.IOException;
import java.io.InputStream;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisUtil {
	// SqlSessionFactory类是单例，只存在一个对象
    private static SqlSessionFactory factory;
    static{
 	  try {
 		  InputStream is = Resources.getResourceAsStream("mybatis-config.xml");
 		  factory = new SqlSessionFactoryBuilder().build(is);
 	   } catch (IOException e) {
 		    e.printStackTrace();
 	    }
     }
    
    public static SqlSession createSqlSession(){
    	// 默认手动提交事务
 	   return factory.openSession(false);
    }
    public static void closeSqlSession(SqlSession session){
    	// 开启自动提交事务
 	   if(null!=session){
 		   session.close();
 	   }  
    }
}
