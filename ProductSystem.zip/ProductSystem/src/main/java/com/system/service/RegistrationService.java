package com.system.service;

public interface RegistrationService {

}
