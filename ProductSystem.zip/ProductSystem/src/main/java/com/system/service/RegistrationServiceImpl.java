package com.system.service;

public class RegistrationServiceImpl implements RegistrationService {

}
