package com.system.service;

import java.util.ArrayList;
import java.util.List;

import com.system.mapper.RegistrationMapper;
import com.system.mapper.impl.RegistrationsMapperImpl;
import com.system.pojo.Registration;

public class RegistrationServiceImpl implements RegistrationService {

	private RegistrationMapper registrationMapper = new RegistrationsMapperImpl();

	@Override
	public int addRegistration(Registration registration) {
		return registrationMapper.addRegistration(registration);
	}

	@Override
	public int delRegistrationByNo(String transactionNo) {
		return registrationMapper.delRegistrationByNo(transactionNo);
	}

	@Override
	public int editRegistrationByNo(Registration registration) {
		return registrationMapper.editRegistrationByNo(registration);
	}

	@Override
	public List<Registration> getRegistrationByDate(String transactionDate) {
		return registrationMapper.getRegistrationByDate(transactionDate);
	}

	@Override
	public List<Registration> getRegistrationBySupplier(String supplier) {
		return registrationMapper.getRegistrationBySupplier(supplier);
	}

	@Override
	public List<Registration> getRegistrationByNo(String transactionNo) {
		return registrationMapper.getRegistrationByNo(transactionNo);
	}

	@Override
	public List<Registration> getRegistrationList() {
		return registrationMapper.getRegistrationList();
	}

	@Override
	public int getRegistrationCount() {
		return registrationMapper.getRegistrationCount();
	}

	@Override
	public List<Registration> getPartAllRegistration(int page, int size) {

		int pageSize = 0;
		List<Registration> rList = registrationMapper.getRegistrationList();
		
		//创建registrationList存放分页处理后的数据
		List<Registration> registrationList = new ArrayList<Registration>();
		//分页处理
        if((page-1) * size + size > rList.size()){	
            pageSize = rList.size();
        }else {
            pageSize = (page-1) * size + size;
        }
        for (int i = (page-1) * size; i < pageSize; i++) {
        	Registration registration = rList.get(i);
        	registrationList.add(registration);
        }
		return registrationList;
	}

}
