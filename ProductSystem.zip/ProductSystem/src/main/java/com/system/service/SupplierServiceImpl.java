package com.system.service;

import java.util.ArrayList;
import java.util.List;
import com.system.mapper.SupplierMapper;
import com.system.mapper.impl.SupplierMapperImpl;
import com.system.pojo.Supplier;

public class SupplierServiceImpl implements SupplierService{
	
	private SupplierMapper supplierMapper = new SupplierMapperImpl();

	@Override
	public int addSupplier(Supplier supplier) {
		return supplierMapper.addSupplier(supplier);
	}

	@Override
	public int delSupplierByNo(String creditCode) {
		return supplierMapper.delSupplierByNo(creditCode);
	}

	@Override
	public int editSupplierByNo(Supplier supplier) {
		return supplierMapper.editSupplierByNo(supplier);
	}

	@Override
	public List<Supplier> getSupplierByCreditCode(String creditCode) {
		return supplierMapper.getSupplierByCreditCode(creditCode);
	}

	@Override
	public List<Supplier> getSupplierByName(String s_name) {
		return supplierMapper.getSupplierByName(s_name);
	}
	
	@Override
	public List<Supplier> getSupplierList() {
		return  supplierMapper.getSupplierList();
	}

	@Override
	public int getSupplierCount() {
		return supplierMapper.getSupplierCount();
	}

	@Override
	public List<Supplier> getPartAllSupplier(int page, int size) {
		int pageSize = 0;
		List<Supplier> sList = supplierMapper.getSupplierList();
		
		//创建detailsLists存放分页处理后的数据
		List<Supplier> supplierList = new ArrayList<Supplier>();
		//分页处理
        if((page-1) * size + size > sList.size()){	
            pageSize = sList.size();
        }else {
            pageSize = (page-1) * size + size;
        }
        for (int i = (page-1) * size; i < pageSize; i++) {
        	Supplier supplier = sList.get(i);
        	supplierList.add(supplier);
        }
		return supplierList;
	}
}
