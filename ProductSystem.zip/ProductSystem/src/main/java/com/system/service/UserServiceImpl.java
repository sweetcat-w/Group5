package com.system.service;

import java.util.ArrayList;
import java.util.List;

import com.system.mapper.UserMapper;
import com.system.mapper.impl.UserMapperImpl;
import com.system.pojo.User;

public class UserServiceImpl implements UserService{
	
	private UserMapper userMapper = new UserMapperImpl();
	

	@Override
	public List<User> userLogin(String userId, String password) {
		return userMapper.getUser(userId, password);
	}

	@Override
	public int addUser(User user) {
	
		return userMapper.addUser(user);
	}

	@Override
	public int delUserByNo(String userId) {
		
		return userMapper.delUserByNo(userId);
	}

	@Override
	public int editUserByNo(User user) {
		
		return userMapper.editUserByNo(user);
	}

	@Override
	public List<User> getUserByName(String userNmae) {
		
		return userMapper.getUserByName(userNmae);
	}

	@Override
	public List<User> getUserByNo(String userId) {
		
		return userMapper.getUserByNo(userId);
	}

	@Override
	public List<User> getUserList() {
	
		return userMapper.getUserList();
	}

	@Override
	public int getUserCount() {
		
		return userMapper.getUserCount();
	}

	@Override
	public List<User> getPartAllUser(int page, int size) {
		
		int pageSize = 0;
		List<User> dList = userMapper.getUserList();
		
		//创建userLists存放分页处理后的数据
		List<User> userList = new ArrayList<User>();
		//分页处理
        if((page-1) * size + size > dList.size()){	
            pageSize = dList.size();
        }else {
            pageSize = (page-1) * size + size;
        }
        for (int i = (page-1) * size; i < pageSize; i++) {
        	User user = dList.get(i);
        	userList.add(user);
        }
		return userList;
	}


}
