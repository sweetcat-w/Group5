package com.system.pojo;

public class User {
	
	private String userId;	//用户userId
	private String userName;	//用户姓名
	private String phoneNum;	//用户电话
	private String password;	//用户密码
	private int isAdmain;	//是否为管理员
	
	public User() {
		super();
	}
	
	public User(String userId) {
		super();
		this.userId = userId;
	}
	
	public User(String userId, String userName) {
		super();
		this.userId = userId;
		this.userName = userName;
	}
	
	public User(String userId, String userName, String phoneNum) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.phoneNum = phoneNum;
	}

	public User(String userId, String userName, String phoneNum, String password) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.phoneNum = phoneNum;
		this.password = password;
	}

	public User(String userId, String userName, String phoneNum, String password, int isAdmain) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.phoneNum = phoneNum;
		this.password = password;
		this.isAdmain = isAdmain;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getIsAdmain() {
		return isAdmain;
	}

	public void setIsAdmain(int isAdmain) {
		this.isAdmain = isAdmain;
	}
	
	
}
