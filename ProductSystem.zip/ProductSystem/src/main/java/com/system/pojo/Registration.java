package com.system.pojo;

import java.util.Date;

public class Registration {
	
    private String transactionNo;	//交易单号
    private String supplier;	//供应商
    private int p_category;	//商品种类数目
    private Date transactionDate;	//交易日期
    private String remarks;	//备注

    public String getTransactionNo() {
        return transactionNo;
    }

    public void setTransactionNo(String transactionNo) {
        this.transactionNo = transactionNo;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public int getP_category() {
        return p_category;
    }

    public void setP_category(int p_category) {
        this.p_category = p_category;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Registration(String transactionNo, String supplier, int p_category, Date transactionDate, String remarks) {
        this.transactionNo = transactionNo;
        this.supplier = supplier;
        this.p_category = p_category;
        this.transactionDate = transactionDate;
        this.remarks = remarks;
    }

    public Registration() {
    }
}
