package com.system.controller.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.pojo.Registration;
import com.system.service.RegistrationService;
import com.system.service.RegistrationServiceImpl;

//新增商品进货登记 AddRegistrationServlert

@WebServlet("/servlet/AddRegistrationServlert")
public class AddRegistrationServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public AddRegistrationServlert() {
    	super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
    	resp.setContentType("text/html;charset=utf-8");
		//实例化接口
    	RegistrationService registrationServiceImpl = new RegistrationServiceImpl();
		//返回调用方法返回获得的进货登记集合
		req.setAttribute("registrationList", registrationServiceImpl.getRegistrationList());
		//返回到添加进货登记页面
		req.getRequestDispatcher("/system/RegistrationAdd.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		
		//获取进货登记的交易单号
		String transactionNo = req.getParameter("transactionNo"); 
		
		//实例化接口
    	RegistrationService registrationServiceImpl = new RegistrationServiceImpl();
		
		//判断交易单号不存在则进行添加操作
		if(registrationServiceImpl.getRegistrationByNo(transactionNo).size() == 0) {
			
			//设置日期格式
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
			
			//获取页面上需要添加的信息
			String supplier = req.getParameter("supplier");	//供货商
			String transactionDate = req.getParameter("transactionDate");	//交易日期
			int p_category = Integer.parseInt(req.getParameter("p_category"));	//商品种类数目
			String remarks = req.getParameter("remarks");	//备注
			
			//创建一个进货登记对象
			Registration registration = new Registration();
			//将相应的信息添加到对象中
			registration.setTransactionNo(transactionNo);
			registration.setSupplier(supplier);
			registration.setP_category(p_category);
			registration.setRemarks(remarks);
			
			Calendar calendar = new GregorianCalendar();

			try {
				calendar.setTime(new Date(simpleDateFormat.parse(transactionDate).getTime()));
				calendar.add(Calendar.DATE,1);
				registration.setTransactionDate(calendar.getTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}

			//实例化接口
			RegistrationService serviceImpl = new RegistrationServiceImpl();
			//调用接口的添加进货登记方法，返回结果到页面并提示
			
			if(serviceImpl.addRegistration(registration) > 0){
				out.write("<script>");
				out.write("alert('【进货登记】添加成功！');");
				out.write("location='GetRegistrationServlert';");
				out.write("</script>");
			}else {
				out.write("<script>");
				out.write("alert('【进货登记】添加失败！');");
				out.write("location='AddRegistrationServlert';");
				out.write("</script>");
			}
		}else {
			out.write("<script>");
			out.write("alert('【进货登记】交易单号已存在，请重新输入！');");
			out.write("location='AddRegistrationServlert';");
			out.write("</script>");
		}
	}

}
