package com.system.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.pojo.User;
import com.system.service.UserService;
import com.system.service.UserServiceImpl;

//修改用户信息 EditUserServlert

@WebServlet("/servlet/EditUserServlert")
public class EditUserServlert extends HttpServlet{
	
private static final long serialVersionUID = 1L;
	
	public EditUserServlert() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
		//获取要修改的用户userId
		String userId = req.getParameter("id");	//userId
		
		req.setAttribute("user", userServiceImpl.getUserByNo(userId).get(0));
		req.getRequestDispatcher("/system/UserEdit.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter out = resp.getWriter();
		
		//获取页面上需要添加的信息
		String userId = req.getParameter("userId");	//userId
		String userName = req.getParameter("userName");	//用户名称
		String password = req.getParameter("password");	//密码
		String phoneNum = req.getParameter("phoneNum");	//用户电话
		String isAdmain = req.getParameter("isAdmain");	//是否为管理员
		
		//创建一个进货明细对象
		User user = new User();
		//将相应的信息添加到对象中
		user.setUserId(userId);
		user.setUserName(userName);
		user.setPassword(password);
		user.setPhoneNum(phoneNum);
		user.setIsAdmain(Integer.parseInt(isAdmain));
		
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
		
		//调用接口的修改用户信息方法，返回结果到页面并提示
		if(userServiceImpl.editUserByNo(user) > 0){
			out.write("<script>");
			out.write("alert('【用户信息管理】修改成功！');");
			out.write("location='GetUserServlert';");
			out.write("</script>");
		}else {
			out.write("<script>");
			out.write("alert('【用户信息管理】修改失败！');");
			out.write("location='AddUserServlert';");
			out.write("</script>");
		}
	}

}
