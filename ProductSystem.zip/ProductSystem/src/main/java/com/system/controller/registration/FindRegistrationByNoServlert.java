package com.system.controller.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.pojo.Registration;
import com.system.service.RegistrationService;
import com.system.service.RegistrationServiceImpl;

//按交易单号查询进货登记 FindRegistrationByNoServlert

@WebServlet("/servlet/FindRegistrationByNoServlert")
public class FindRegistrationByNoServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public FindRegistrationByNoServlert() {
    	super();
    }

    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		
		//获取要查找的进货登记的交易单号
		String transactionNo = req.getParameter("transactionNo");
		
		//判断交易单号是否为空
		if(transactionNo.equals("")) {
			out.write("<script>");
			out.write("alert('【进货登记】请输入要查找的交易单号！');");
			out.write("location='GetRegistrationServlert';");
			out.write("</script>");
		}
		
		//实例化接口
		RegistrationService registrationServiceImpl = new RegistrationServiceImpl();
		//调用接口的按交易单号查询进货登记方法，返回结果到页面并提示
		List<Registration> registrationList = registrationServiceImpl.getRegistrationByNo(transactionNo);
		
		if(registrationList.size() > 0) {
			req.setAttribute("list", registrationList);
			req.getRequestDispatcher("/system/RegistrationList.jsp").forward(req, resp);
		}else {
			out.write("<script>");
			out.write("alert('【进货登记】没有找到相关交易单号的信息！');");
			out.write("location='GetRegistrationServlert';");
			out.write("</script>");
			return;
		}
	}

    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
