package com.system.controller.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.pojo.Registration;
import com.system.service.RegistrationService;
import com.system.service.RegistrationServiceImpl;

//修改商品进货登记 EditRegistrationServlert

@WebServlet("/servlet/EditRegistrationServlert")
public class EditRegistrationServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public EditRegistrationServlert() {
    	super();
    }
    

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		//实例化接口
		RegistrationService registrationServiceImpl = new RegistrationServiceImpl();
		//获取要修改的进货登记的交易单号
		String transactionNo = req.getParameter("id");
		
		req.setAttribute("registration", registrationServiceImpl.getRegistrationByNo(transactionNo).get(0));
		req.getRequestDispatcher("/system/RegistrationEdit.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter out = resp.getWriter();
		
		//设置日期格式
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		//获取页面上需要添加的信息

		String transactionNo = req.getParameter("transactionNo");	//交易单号
		String supplier = req.getParameter("supplier");	//供货商
		int p_category = Integer.parseInt(req.getParameter("p_category"));	//商品种类数目
		String transactionDate = req.getParameter("transactionDate");	//交易日期
		String remarks = req.getParameter("remarks");	//备注
		
		
		//创建一个进货登记对象
		Registration registration = new Registration();
		//将相应的信息修改到对象中
		registration.setTransactionNo(transactionNo);
		registration.setSupplier(supplier);
		registration.setP_category(p_category);
		registration.setRemarks(remarks);
		
		Calendar calendar = new GregorianCalendar();

		try {
			calendar.setTime(new Date(simpleDateFormat.parse(transactionDate).getTime()));
			calendar.add(Calendar.DATE,1);
			registration.setTransactionDate(calendar.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		//实例化接口
		RegistrationService registrationServiceImpl = new RegistrationServiceImpl();
		
		//调用接口的修改进货登记方法，返回结果到页面并提示
		if(registrationServiceImpl.editRegistrationByNo(registration) > 0){
			out.write("<script>");
			out.write("alert('【进货登记】修改成功！');");
			out.write("location='GetRegistrationServlert';");
			out.write("</script>");
		}else {
			out.write("<script>");
			out.write("alert('【进货登记】修改失败！');");
			out.write("location='AddRegistrationServlert';");
			out.write("</script>");
		}
	}

}
