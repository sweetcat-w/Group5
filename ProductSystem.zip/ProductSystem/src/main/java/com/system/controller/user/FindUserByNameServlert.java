package com.system.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.system.pojo.User;
import com.system.service.UserService;
import com.system.service.UserServiceImpl;

//按用户名称查询用户信息 FindUserByIdServlert
@WebServlet("/servlet/FindUserByNameServlert")
public class FindUserByNameServlert  extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	public FindUserByNameServlert() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		
		//获取要查找的用户名称
		String userName = req.getParameter("userName");
		
		//判断商品名称是否为空
		if(userName.equals("")) {
			out.write("<script>");
			out.write("alert('【用户信息管理】请输入要查找的用户名称！');");
			out.write("location='GetUserServlert';");
			out.write("</script>");
		}
		
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
		//调用接口的按用户名称查询用户的方法，返回结果到页面并提示
		List<User> userList = userServiceImpl.getUserByName(userName);
		
		if(userList.size() > 0) {
			req.setAttribute("list", userList);
			req.getRequestDispatcher("/system/UserList.jsp").forward(req, resp);
		}else {
			out.write("<script>");
			out.write("alert('【用户信息管理】没有找到相关用户的信息！');");
			out.write("location='GetUserServlert';");
			out.write("</script>");
			return;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
