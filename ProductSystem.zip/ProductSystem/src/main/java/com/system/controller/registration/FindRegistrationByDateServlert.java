package com.system.controller.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.pojo.Registration;
import com.system.service.RegistrationService;
import com.system.service.RegistrationServiceImpl;

//按交易日期查询进货登记 FindRegistrationByDateServlert

@WebServlet("/servlet/FindRegistrationByDateServlert")
public class FindRegistrationByDateServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public FindRegistrationByDateServlert() {
    	super();
    }

    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		
		//获取要查找的进货登记的商品日期
		String transactionDate = req.getParameter("transactionDate");
		
		//判断商品日期是否为空
		if(transactionDate.equals("")) {
			out.write("<script>");
			out.write("alert('【进货登记】请输入要查找的商品日期！');");
			out.write("location='GetRegistrationServlert';");
			out.write("</script>");
		}

		//实例化接口
		RegistrationService registrationServiceImpl = new RegistrationServiceImpl();
		//调用接口的按日期查询进货登记方法，返回结果到页面并提示
		List<Registration> registrationList = registrationServiceImpl.getRegistrationByDate(transactionDate);
		
		if(registrationList.size() > 0) {
			req.setAttribute("list", registrationList);
			req.getRequestDispatcher("/system/RegistrationList.jsp").forward(req, resp);
		}else {
			out.write("<script>");
			out.write("alert('【进货登记】没有找到相关商品日期的信息！');");
			out.write("location='GetRegistrationServlert';");
			out.write("</script>");
			return;
		}
	}

    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
