package com.system.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servlet/UserLoginOut")
public class UserLoginOut extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//将session对象注销
		request.getSession().invalidate();
		//跳转登录页面
		//重定向
		response.sendRedirect(request.getContextPath() + "/system/login.jsp");
	}
}
