package com.system.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.system.pojo.User;
import com.system.service.UserService;
import com.system.service.UserServiceImpl;

@WebServlet("/servlet/UserLogin")

public class UserLogin extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//解决中文乱码
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		//接收前端数据
		String userId = request.getParameter("userId");
		String password  = request.getParameter("password");
		
		//处理数据
		UserService userService = new UserServiceImpl();
		List<User> user = userService.userLogin(userId, password);
		if(user != null && user.size()>0) {
			//获得session对象
			HttpSession session = request.getSession();
			//把指定的对象存入到session
			session.setAttribute("user", user.get(0));
			session.setAttribute("isLogin", "1");
			session.setMaxInactiveInterval(30*60);
			//统计登录过的人数
			ServletContext context = request.getServletContext();
			Integer count = (Integer)context.getAttribute("count");
			if(count == null){
				count = 1;
			}else {
				count++;
			}
			context.setAttribute("count", count);
			
			//重定向
			response.sendRedirect(request.getContextPath()+"/system/index.jsp");
		}else {
			PrintWriter out = response.getWriter();
			out.write("<script>");
			out.write("alert('用户名或密码错误');");
			out.write("location='/ProductSystem/system/login.jsp';");
			out.write("</script>");
		}
	}
}
