package com.system.controller.registration;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.service.RegistrationService;
import com.system.service.RegistrationServiceImpl;

//删除商品进货登记 DelRegistrationServlert

@WebServlet("/servlet/DelRegistrationServlert")
public class DelRegistrationServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public DelRegistrationServlert() {
    	super();
    }
    
    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
	
		PrintWriter out = resp.getWriter();
		//获取要删除的进货登记的交易单号
		String transactionNo = req.getParameter("id");
		
		//实例化接口
		RegistrationService registrationServiceImpl = new RegistrationServiceImpl();
		//调用接口的根据交易单号删除方法
		if(registrationServiceImpl.delRegistrationByNo(transactionNo) > 0) {
			out.write("<script>");
			out.write("alert('删除成功');");
			out.write("location='GetRegistrationServlert';");
			out.write("</script>");
		}else {
			out.write("<script>");
			out.write("alert('删除失败');");
			out.write("location='GetRegistrationServlert';");
			out.write("</script>");
		}
	}

    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
