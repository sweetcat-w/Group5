package com.system.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.pojo.User;
import com.system.service.UserService;
import com.system.service.UserServiceImpl;

//新增用户信息 AddUserServlert

@WebServlet("/servlet/AddUserServlert")

public class AddUserServlert extends HttpServlet{
	
private static final long serialVersionUID = 1L;
	
    public AddUserServlert() {
        super();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
    	resp.setContentType("text/html;charset=utf-8");
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
		//返回调用方法返回获得的用户集合
		req.setAttribute("userList", userServiceImpl.getUserList());
		//返回到添加用户信息页面
		req.getRequestDispatcher("/system/UserAdd.jsp").forward(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();

		
		//获取用户userId
		String userId = req.getParameter("userId");	//userId
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
		//判断userId是否存在，若是不存在则添加
		if(userServiceImpl.getUserByNo(userId).size() == 0) {
			
			//获取页面上需要添加的信息
			String userName = req.getParameter("userName");	//用户名称
			String password = req.getParameter("password");	//密码
			String phoneNum = req.getParameter("phoneNum");	//用户电话
			String isAdmain = req.getParameter("isAdmain");	//是否为管理员
			
			//创建一个进货明细对象
			User user = new User();
			//将相应的信息添加到对象中
			user.setUserId(userId);
			user.setUserName(userName);
			user.setPassword(password);
			user.setPhoneNum(phoneNum);
			user.setIsAdmain(Integer.parseInt(isAdmain));

			
			//调用接口的添加用户方法，返回结果到页面并提示
			
			if(userServiceImpl.addUser(user) > 0){
				out.write("<script>");
				out.write("alert('【用户信息管理】添加成功！');");
				out.write("location='GetUserServlert';");
				out.write("</script>");
			}else {
				out.write("<script>");
				out.write("alert('【用户信息管理】添加失败！');");
				out.write("location='AddUserServlert';");
				out.write("</script>");
			}
		}else {
			out.write("<script>");
			out.write("alert('【用户信息管理】已存在，请重新输入！');");
			out.write("location='AddUserServlert';");
			out.write("</script>");
		}
    }   
    
}
