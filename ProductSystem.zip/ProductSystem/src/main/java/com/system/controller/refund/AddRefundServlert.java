package com.system.controller.refund;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.pojo.Refund;
import com.system.service.RefundService;
import com.system.service.RefundServiceImpl;

//新增商品退货登记 AddRefundServlert

@WebServlet("/servlet/AddRefundServlert")
public class AddRefundServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public AddRefundServlert() {
    	 super();
    }

    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
    	resp.setContentType("text/html;charset=utf-8");
		//实例化接口
    	RefundService refundServiceImpl = new RefundServiceImpl();
		//返回调用方法返回获得的进货明细集合
		req.setAttribute("refundList", refundServiceImpl.getRefundList());
		//返回到删除退货登记页面
		req.getRequestDispatcher("/system/RefundAdd.jsp").forward(req, resp);
	}

    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//设置参数和页面的编码格式
    	req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		
		//获取退货登记的交易单号
		String transactionNo = req.getParameter("transactionNo"); 
		
		//实例化接口
    	RefundService refundServiceImpl = new RefundServiceImpl();
		//判断交易单号存在则进行删除操作
		if(refundServiceImpl.getRefundByNo(transactionNo).size() == 0) {
			
			//设置日期格式
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
			
			//获取页面上需要删除的信息
			
			String g_name = req.getParameter("g_name");	//商品名称
			String g_barCode = req.getParameter("g_barCode");	//商品条形码
			String g_manufactureDate = req.getParameter("g_manufactureDate");	//生产日期
			int R_num = Integer.parseInt(req.getParameter("r_num"));	//数量
			String g_specifications = req.getParameter("g_specifications");	//规格
			String g_unit = req.getParameter("g_unit");	//单位
			String r_date = req.getParameter("r_date");	//退货日期
			
			//创建一个退货登记对象
			Refund refund= new Refund();
			//将相应的信息添加到对象中
			refund.setTransactionNo(transactionNo);
			refund.setG_name(g_name);
			refund.setG_barCode(g_barCode);
			refund.setR_num(R_num);
			refund.setG_specifications(g_specifications);
			refund.setG_unit(g_unit);

			
			Calendar calendar = new GregorianCalendar();
			try {
				
				calendar.setTime(new Date(simpleDateFormat.parse(g_manufactureDate).getTime()));
				calendar.add(Calendar.DATE,1);
				refund.setG_manufactureDate(calendar.getTime());
				
				calendar.setTime(new Date(simpleDateFormat.parse(r_date).getTime()));
				calendar.add(Calendar.DATE,1);
				refund.setR_date(calendar.getTime());
				
			} catch (ParseException e) {
				e.printStackTrace();
			}

			//实例化接口
			RefundService serviceImpl = new RefundServiceImpl();
			//调用接口的添加退货登记方法，返回结果到页面并提示
			if(serviceImpl.addRefund(refund) > 0){
				out.write("<script>");
				out.write("alert('【退货登记】添加成功！');");
				out.write("location='GetRefundServlert';");
				out.write("</script>");
			}else {
				out.write("<script>");
				out.write("alert('【退货登记】添加失败！');");
				out.write("location='AddRefundServlert';");
				out.write("</script>");
			}
		}else {
			out.write("<script>");
			out.write("alert('【退货登记】交易单号已存在，请重新输入！');");
			out.write("location='AddRefundServlert';");
			out.write("</script>");
		}
	}
}
