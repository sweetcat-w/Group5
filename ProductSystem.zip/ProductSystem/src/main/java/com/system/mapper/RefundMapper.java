package com.system.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.system.pojo.Refund;

public interface RefundMapper {
	/**
	 * 添加商品退货登记
	 * @param refund 添加的信息
	 * @return 影响行数
	 */
	public int addRefund(Refund refund); 
	
	/**
	 * 按商品条形码删除退货登记
	 * @param g_barCode 商品条形码
	 * @return 影响行数
	 */
	public int delRefundByNo(@Param("g_barCode") String g_barCode);
	
	/**
	 * 按商品条形码修改退货登记
	 * @param refund 修改的内容
	 * @return
	 */
	public int editRefundByNo(Refund refund);
	
	/**
	 * 按商品条形码查询退货登记
	 * @param g_barCode 商品条形码
	 * @return 查询结果
	 */
	public List<Refund> getRefundByBarCode(@Param("g_barCode") String g_barCode);

	/**
	 * 按退货日期查询退货登记
	 * @param r_date 退货日期
	 * @return 查询结果
	 */
	public List<Refund> getRefundByDate(@Param("r_date") String r_date);
	
	/**
	 * 按交易单号查询退货登记
	 * @return 查询结果
	 */
	public List<Refund> getRefundByNo(@Param("transactionNo") String transactionNo);
		
	/**
	 * 获取全部退货登记
	 * @return 退货登记列表
	 */
	public List<Refund> getRefundList();
	
	/**
	 * 获取全部退货登记总数
	 * @return 统计结果
	 */
	public int getRefundCount();


}

