package com.system.mapper;

import java.util.List;
import com.system.pojo.Registration;

public class RegistrationsMapperImpl implements RegistrationMapper{

	@Override
	public int addRegistration(Registration registration) {
		return 0;
	}

	@Override
	public int delRegistrationServiceByNo(String transactionNo) {
		return 0;
	}

	@Override
	public int editRegistrationByNo(Registration registration) {
		return 0;
	}

	@Override
	public List<Registration> getRegistrationByDate(String transactionDate) {
		return null;
	}

	@Override
	public List<Registration> getRegistrationBySupplier(String supplier) {
		return null;
	}

	@Override
	public List<Registration> getRegistrationByNo(String transactionNo) {
		return null;
	}

	@Override
	public List<Registration> getRegistrationList() {
		return null;
	}

	@Override
	public int getRegistrationCount() {
		return 0;
	}

	@Override
	public List<Registration> getPartAllRegistration(int page, int size) {
		return null;
	}

}
