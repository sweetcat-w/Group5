package com.system.controller.refund;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.system.service.RefundService;
import com.system.service.RefundServiceImpl;

//删除商品退货登记 DelRefundServlert
@WebServlet("/DelRefundServlert")
public class DelRefundServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public DelRefundServlert() {
    	super();
    }
    
    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
	
		//获取要删除的退货登记的交易单号
		String transactionNo = req.getParameter("transactionNo");
		
		//实例化接口
		RefundService RefundServiceImpl = new RefundServiceImpl();
	
		//调用接口的根据交易单号删除方法
		if(refundServiceImpl.delRefundByNo(transactionNo) > 0) {
			out.write("<script>");
			out.write("alert('删除成功');");
			out.write("location='GetClassesListServlert';");
			out.write("</script>");
		}else {
			out.write("<script>");
			out.write("alert('删除失败');");
			out.write("location='GetClassesListServlert';");
			out.write("</script>");
		}
	}

    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
