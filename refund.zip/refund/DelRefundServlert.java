package com.system.controller.refund;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.system.service.RefundService;
import com.system.service.RefundServiceImpl;

/**
 * Servlet implementation class DelRefundServlert
 */
@WebServlet("/DelRefundServlert")
public class DelRefundServlert extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public DelRefundServlert() {
        // TODO Auto-generated constructor stub
    	super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//���ò�����ҳ��ı����ʽ
				req.setCharacterEncoding("utf-8");
				resp.setContentType("text/html;charset=utf-8");
				
				PrintWriter out = resp.getWriter();
			
				//��ȡҪɾ���Ľ�����ϸ�Ľ��׵���
				String transactionNo = req.getParameter("transactionNo");
				
				//ʵ�����ӿ�
				RefundService RefundServiceImpl = new RefundServiceImpl();
			
				//���ýӿڵĸ��ݽ��׵���ɾ������
				if(refundServiceImpl.delRefundByNo(transactionNo) > 0) {
					out.write("<script>");
					out.write("alert('ɾ���ɹ�');");
					out.write("location='GetClassesListServlert';");
					out.write("</script>");
				}else {
					out.write("<script>");
					out.write("alert('ɾ��ʧ��');");
					out.write("location='GetClassesListServlert';");
					out.write("</script>");
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
