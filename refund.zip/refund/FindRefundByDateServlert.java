package com.system.controller.refund;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.system.pojo.Refund;
import com.system.service.RefundService;
import com.system.service.RefundServiceImpl;

//按退货日期查询退货登记 FindRefundByRDateServlert
@WebServlet("/FindRefundByRDateServlert")
public class FindRefundByDateServlert extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    public FindRefundByDateServlert() {
    	super();
    }

    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    	//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		//获取发送到HttpSession的数据来为新页面提供内容
		HttpSession session = req.getSession();
		
		//获取要查找的退货登记的交易单号
		String r_date = req.getParameter("r_date");
		
		//判断交易单号是否为空
		if(r_date.equals("")) {
			out.write("<script>");
			out.write("alert('【退货登记】请输入要查找的交易单号！');");
			out.write("location='GetRefundListServlert';");
			out.write("</script>");
		}
		
		//实例化接口
		RefundService refundServiceImpl = new RefundServiceImpl();
		//调用接口的按交易单号查询退货登记方法，返回结果到页面并提示
		List<Refund> refundList = refundServiceImpl.getRefundByDate(r_date);
		
		if(refundList.size() > 0) {
			req.setAttribute("list", refundList);
			req.getRequestDispatcher("/manager/RefundList.jsp").forward(req, resp);
		}else {
			out.write("<script>");
			out.write("alert('【退货登记】没有找到相关交易单号的信息！');");
			out.write("location='GetRefundListServlert';");
			out.write("</script>");
			return;
		}
	}

    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
