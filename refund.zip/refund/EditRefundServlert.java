package com.system.controller.refund;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.system.service.RefundService;
import com.system.service.RefundServiceImpl;

/**
 * Servlet implementation class EditRefundServlert
 */
@WebServlet("/EditRefundServlert")
public class EditRefundServlert extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public EditRefundServlert() {
        // TODO Auto-generated constructor stub
    	super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		//ʵ�����ӿ�
		RefundService detailsServiceImpl = new RefundServiceImpl();
		//��ȡҪ�޸ĵĽ�����ϸ�Ľ��׵���
		String transactionNo = req.getParameter("transactionNo");
		
		req.setAttribute("refund", detailsServiceImpl.getRefundByNo(transactionNo).get(0));
		resp.getRequestDispatcher("/manager/DetailsEdit.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter out = resp.getWriter();
		
		//�������ڸ�ʽ
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
		
		//��ȡҳ������Ҫ���ӵ���Ϣ
		String suppler = req.getParameter("suppler");	//������
		String transactionDate = req.getParameter("transactionDate");	//��������
		String g_name = req.getParameter("g_name");	//��Ʒ����
		String g_barCode = req.getParameter("g_barCode");	//��Ʒ������
		String g_manufactureDate = req.getParameter("g_manufactureDate");	//��������
		int g_num = Integer.parseInt(req.getParameter("g_num"));	//����
		String g_specification = req.getParameter("g_specification");	//���
		String g_unit = req.getParameter("g_unit");	//��λ
		String g_type = req.getParameter("g_type");	//��Ʒ����
		int g_shelfLife = Integer.parseInt("g_shelfLife");	////������
		
		//����һ��������ϸ����
		Refund refund = new Refund();
		//����Ӧ����Ϣ�޸ĵ�������
		refund.setTransactionNo(transactionNo);
		refund.setSuppler(suppler);
		refund.setTransactionDate(new Date(simpleDateFormat.parse(transactionDate).getTime()));
		refund.setG_name(g_name);
		refund.setG_barCode(g_barCode);
		refund.setG_manufactureDate(new Date(simpleDateFormat.parse(g_manufactureDate).getTime()))
		refund.setG_num(g_num);
		refund.setG_specification(g_specification);
		refund.setG_unit(g_unit);
		refund.setG_type(g_type);
		refund.setG_shelfLife(g_shelfLife);
		
		//ʵ�����ӿ�
		RefundService detailsServiceImpl = new RefundServiceImpl();
		
		//���ýӿڵ��޸Ľ�����ϸ���������ؽ����ҳ�沢��ʾ
		if(detailsServiceImpl.editDetailsByNo(refund) > 0){
			out.write("<script>");
			out.write("alert('��������ϸ���޸ĳɹ���');");
			out.write("location='GetDetailsListServlert';");
			out.write("</script>");
		}else {
			out.write("<script>");
			out.write("alert('��������ϸ���޸�ʧ�ܣ�');");
			out.write("location='AddDetailsServlert';");
			out.write("</script>");
		}
	}
	

}
