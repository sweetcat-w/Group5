package com.system.pojo;

public class User {
	private String id;//用户id
	private String userName;//用户姓名
	private String phoneNum;//用户电话
	private String password;//用户密码
	private boolean isAdmain;//是否为管理员
	//构造方法
	public User() {
	}
	
	public User(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	public User(String id, String userName, String phoneNum, String password, boolean isAdmain) {
		super();
		this.id = id;
		this.userName = userName;
		this.phoneNum = phoneNum;
		this.password = password;
		this.isAdmain = isAdmain;
	}
	//获得id
	public String getId() {
		return id;
	}
	//写入id
	public void setId(String id) {
		this.id = id;
	}
	//获得名字
	public String getUserName() {
		return userName;
	}
	//写入名字
	public void setUserName(String userName) {
		this.userName = userName;
	}
	//获得电话
	public String getPhoneNum() {
		return phoneNum;
	}
	//写入电话
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	//获得密码
	public String getPassword() {
		return password;
	}
	//写入密码
	public void setPassword(String password) {
		this.password = password;
	}
	//获得管理员判断
	public boolean isAdmain() {
		return isAdmain;
	}
	//写入管理员判断
	public void setAdmain(boolean isAdmain) {
		this.isAdmain = isAdmain;
	}
	
	
}
