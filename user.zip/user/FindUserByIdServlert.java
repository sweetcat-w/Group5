package com.system.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.system.pojo.Details;
import com.system.pojo.User;

//按用户账号查询用户信息
@WebServlet("/servlet/FindUserByIdServlert")
public class FindUserByIdServlert extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	public FindUserByIdServlert() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		//获取发送到HttpSession的数据来为新页面提供内容
		HttpSession session = req.getSession();
		
		//获取要查找的用户名称
		String name = req.getParameter("name");
		
		//判断商品名称是否为空
		if(name.equals("")) {
			out.write("<script>");
			out.write("alert('【用户】请输入要查找的用户名称！');");
			out.write("location='GetDetailsListServlert';");
			out.write("</script>");
		}
		
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
		//调用接口的按商品名称查询进货明细方法，返回结果到页面并提示
		List<User> userList = userServiceImpl.getUserByName(name);
		
		if(userList.size() > 0) {
			req.setAttribute("list", userList);
			req.getRequestDispatcher("/manager/UserList.jsp").forward(req, resp);
		}else {
			out.write("<script>");
			out.write("alert('【用户】没有找到相关用户的信息！');");
			out.write("location='GetDetailsListServlert';");
			out.write("</script>");
			return;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
