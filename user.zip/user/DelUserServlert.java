package com.system.controller.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//删除用户信息
@WebServlet("/servlet/DelUserServlert")
public class DelUserServlert extends HttpServlet{
private static final long serialVersionUID = 1L;
	
	public DelUserServlert() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//设置参数和页面的编码格式
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = resp.getWriter();
	
		//获取要删除的用户id
		String id = req.getParameter("id");	//id
		
		//实例化接口
		UserService userServiceImpl = new UserServiceImpl();
	
		//调用接口的根据用户id删除方法
		if(userServiceImpl.delUserByNo(id) > 0) {
			out.write("<script>");
			out.write("alert('删除成功');");
			out.write("location='GetClassesListServlert';");
			out.write("</script>");
		}else {
			out.write("<script>");
			out.write("alert('删除失败');");
			out.write("location='GetClassesListServlert';");
			out.write("</script>");
		}
	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
