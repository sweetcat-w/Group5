package com.system.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.system.pojo.User;

public interface UserService {
	/**
	 * 添加用户信息
	 * @param user 添加的信息
	 * @return 影响行数
	 */
	public int addUser(User user);
	
	/**
	 * 按id删除用户信息
	 * @param id 用户id
	 * @return 影响行数
	 */
	public int delUserByNo(@Param("id") String id);
	
	/**
	 * 按id修改用户信息
	 * @param id 用户id
	 * @return  
	 */
	public int editUserByNo(User user);
	

	/**
	 * 按用户名称查询用户信息
	 * @param name 用户名称
	 * @return 查询结果
	 */
	public List<User> getUserByName(@Param("name") String name);
	
	/**
	 * 按id查询用户信息
	 * @return 查询结果
	 */
	public List<User> getUserByNo(@Param("id") String id);
		
	/**
	 * 获取全部用户信息
	 * @return 用户列表
	 */
	public List<User> getUserList();
	
	/**
	 * 获取全部用户总数
	 * @return 统计结果
	 */
	public int getUserCount();
	
	/**
	 * 分页处理进货明细
	 * @param page 页
	 * @param size 分页大小
	 * @return
	 */
	public List<User> getPartAllUser(int page, int size);

}
