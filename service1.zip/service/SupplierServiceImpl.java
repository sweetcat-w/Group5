package com.system.service;

import java.util.List;

import com.system.pojo.Supplier;

public class SupplierServiceImpl implements SupplierService{



	

	@Override
	public int addSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		return 0;
	}

	public static Object getBySupplierCreditCode(String creditCodeNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delDetailsByNo(String creditCode) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getDetailsByNo(String creditCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int editDetailsByNo(Supplier supplier) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Supplier> getDetailsByBarCode(String creditCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Supplier> getSupplierByName(String s_name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getSupplierCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Supplier> getPartAllSupplier(int currentIndex, int size) {
		// TODO Auto-generated method stub
		return null;
	}





}
