package com.system.service;

public class StockServiceImpl implements StockService {

}
