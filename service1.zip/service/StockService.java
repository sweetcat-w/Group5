package com.system.service;

public interface StockService {

}
